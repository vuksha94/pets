import { Component, OnInit, OnDestroy, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { AuthenticationService, AlertService} from '../_services';
import { User } from '../_models';
import { Router, RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { environment } from '../../environments/environment';

/*
* Za jQuery i dhtmlwindow.js i dhtmlwindow.css koji su ucitani u index.html fajlu
*/
declare var jquery: any;
declare var $: any;
declare var dhtmlwindow: any;

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy {

  @ViewChild('profileModal') profileModal: TemplateRef<any>;

  currentUser: User = null;
  userSubscription: Subscription;
  loggedIn: boolean;

  constructor(private authenticationService: AuthenticationService,
              private alertService: AlertService,
              private router: Router,
              private modal: NgbModal) {}
/*Trebalo bi srediti da se provera da li je user ulogovan odradi u metodi loggedInStatusChange
    jer ne radi samo za prvi put subscribe metod -> resenje: umesto Subject -> BehaviorSubject
    ****URADJENO****
*/
  ngOnInit() {
    /*this.userSubscription = this.authenticationService.isLoggedIn()
      .subscribe(loggedIn => {
        this.currentUser = this.authenticationService.CurrentUser ? this.authenticationService.CurrentUser : null;
        this.loggedIn = this.currentUser != null;
      });*/
    
    this.userSubscription = this.authenticationService.isLoggedIn()
      .subscribe(loggedIn => {
        if (loggedIn) {
          // console.log("NavbarComponent: logged");
          this.loggedIn = true;
          this.currentUser = this.authenticationService.CurrentUser;
        } else {
          // console.log("NavbarComponent: not logged");
          this.loggedIn = false;
          this.currentUser = null;
        }
      });

  }

  openProfileModal() {
    this.modal.open(this.profileModal, { size: 'lg' });
  }


  ngOnDestroy() {
    //this.userSubscription.unsubscribe();
  }
  logOut(){
    this.alertService.success('Uspešno ste se odjavili!', true);
    this.router.navigate(['/login']);
  }


}
