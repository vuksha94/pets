import { InfoData } from './info-data';
// import { PetInfo } from './pet-info';

export interface PetInfoData {
    info: InfoData;
    petInfo: any;
    petId: string;
}

