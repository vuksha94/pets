export interface InfoData {
    type: string;
    success: boolean;
    msg: string;
  }