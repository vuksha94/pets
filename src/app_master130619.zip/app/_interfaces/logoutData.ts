export interface logoutData {
    success: boolean
}